=== FirmaSite ===
You can find detailed information, showcase, live demo, 
tips and tricks about theme in:
http://theme.firmasite.com/

You can find theme option instructions in right of options in Theme Customizer.


== License ==
GNU GENERAL PUBLIC LICENSE v3 or later


== License URI ==
license.txt

== Theme Re-Distribution ==
GPLv3 License needs to stay as well as all copyright notices 
included in all parts of this Theme as well as third-party add-ons.

== Changelog ==
You can find all releases' changelog in http://theme.firmasite.com/category/changelog/
